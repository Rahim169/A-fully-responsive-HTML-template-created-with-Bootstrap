$('.slider').slick({
  autoplay: true,
  autoplaySpeed: 2000,
  slideToShow: 1,
  slideToScroll: 1
});
